
//change password
var express = require('express')
var https = require('https')
const path = require('path')
const fs=require('fs')
var cors = require('cors')
var bodyParser = require('body-parser')
var userBL = require('./models/userBL')
var userController = require('./controllers/userController')
var userJsonController = require('./controllers/LoginIndedCo')
var appRouter = express.Router()
var passwordconf = require('./PasswordConfig/ConfigPassword')
var mailControler =require('./controllers/mailController')
var jwtBL = require('./models/jwtBL')
require('./configs/UsersDataBase')
var app = express();

app.use(cors())
app.use(bodyParser.urlencoded({extended:true})).use(bodyParser.json())
app.use('/users',userController)
app.use('/Permission',userJsonController)
app.use('/mail',mailControler)

app.use('/PasswordReq',(req,res,next)=>{
    res.json(passwordconf)})

app.use('/userinjection',async (req,res)=>{
        console.log("Inject")
        var  users = await userBL.injectionDB(req.body);
        res.json(users)
    })
    app.post('/injectlogin', async function(req, res) {
        console.log("InjectLogin")
        console.log(req.body)
        var token="";
        var  users = await userBL.injectionLoginDB(req.body);
        if (users.Auth=="Login") 
        {
         token = await jwtBL.makeToken();
        }
        res.json({Auth:users.Auth,"Token":token})
    });
    
      
app.use('/',(req,res,next)=>{
res.send('hello ssl')})

const sslServer = https.createServer({
    key: fs.readFileSync(path.join(__dirname,'cert','key.pem')),
    cert:fs.readFileSync(path.join(__dirname,'cert','cert.pem'))
},app)

sslServer.listen(3001 , ()=> console.log("secure server in 3001"))