var User = require ('./userSchema')

var getAllUsers = () => {
    return new Promise((resolve,reject)=>{
        User.find({},(err,data)=>{
            if(err){
                reject(err);
            }
            else{
                console.log(data);
                resolve(data);
            }
        })
    })
}

var getUserById = (UserId) => {
    return new Promise ((resolve,reject)=>{
        User.findById( UserId,(err,data)=>{
            if(err){
                reject(err)
            }
            else{
                resolve(data)
            }
        })
    })
}

var addUser = (newUser) => {
    return new Promise((resolve,reject)=>{
        
        var UserToDB = new User ({
            userName: newUser.userName,
            email: newUser.email,
            password:newUser.password
        })

        console.log(UserToDB);

        UserToDB.save((err)=>{
            if(err){
                reject(err)
            }
            else{
                resolve(UserToDB)
            }
        })
    })
}

var updateUser = (UserId,newUser) => {
    return new Promise((resolve,reject)=>{
        
        var updateUser = {
            userName: newUser.userName,
            password: newUser.password
        }

        User.findByIdAndUpdate(UserId,updateUser,(err)=>{
            if(err){
                reject(err)
            }
            else{
                resolve("User was updated")
            }
        })
    })
}

var deleteUser = (UserId) => {
    return new Promise((resolve,reject)=>{
        User.findByIdAndDelete(UserId,(err)=>{
            if(err){
                reject(err)
            }
            else{
                resolve("User deleted!!!")
            }
        })
    })
}

var injectionDB = async (str2) =>{
    return new Promise((resolve,reject)=>{
     User.find(str2,(err,data)=>{resolve(data)});
  
})
}

var injectionLoginDB = async (str2) =>{
    return new Promise((resolve,reject)=>{
        var str="";
        var status =false;
    console.log(str2)
    //eval(str2)
    //resolve(ans);
     User.find({str2},(err,data)=>{
        for (var i=0;i<data.length;i++)
        {
            if(data[i].userName == str2.userName)
            {
                status=true;

                resolve({"Auth":"Login"})
            }
        } 
        if(status ==false)
        resolve({"Auth":"Dont Login"});
  
})
    })
}


var getIdNumber = (userName) => {
    return new Promise((resolve,reject)=>{
        User.find({},(err,data)=>{
            if(err){
                reject(err);
            }
            else{
                console.log(data);
                for (var i=0;i<data.length;i++)
                {
                    if (data[i].userName == userName)
                    resolve(data[i])
                }
                resolve("Didnt Found");
            }
        })
    })
}


module.exports = {getAllUsers, getUserById, addUser, updateUser, deleteUser,getIdNumber,injectionDB,injectionLoginDB }