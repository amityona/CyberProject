var express = require ('express')
var app = express();
var appRouter = express.Router()
var nodemailer = require('nodemailer');
var crypto = require('crypto')
var userBL = require('../models/userBL')
const UserJson = require('../LoginDataBase/LoginDataBaseController');
const PasswordConfig = require('../PasswordConfig/passwordConfig')
const LoginDatabaseCOntroler = require('../LoginDataBase/LoginDataBaseController')
const ConfigPass =require('../PasswordConfig/ConfigPassword')
//mail
var emails=[];
var sha1passwords=[];
/*
var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'cyberProjectAmit@gmail.com',
      pass: 'cyberProjectAmit1212'
    }
  });
  */
  var transporter = nodemailer.createTransport({
    host: "smtp.mailtrap.io",
    port: 2525,
    auth: {
      user: "a68c2c2ad73faf",
      pass: "85ebf75697711a"
    }
  });
  var mailOptions = {
    from: 'cyberProjectAmit@gmail.com',
    to: 'amityon1212@walla.co.il',
    subject: 'Rest Password ',
    text: 'That was easy!'
  };
//https://mailtrap.io/inboxes/1521400/messages# WORK MY EMAIL
  // {to :  }
appRouter.route('/').post(async(req,resp)=>{
    var getanswer = await userBL.getAllUsers();
    var obj = req.body;
    var emailto =obj.to;
    var status=false;
    for (var i=0;i<getanswer.length;i++) {
       if(emailto==getanswer[i].email)
        status=true;
    }
    if (status ==true) {
     var current_date = (new Date()).valueOf().toString();
     var emailtoenc = emailto;
     var random = Math.random().toString();
     var sha1pass = crypto.createHash('sha1').update(emailtoenc + random + current_date).digest('hex'); // random sha1
    emails.push(obj.to)
    sha1passwords.push(sha1pass)
    console.log("Emails Array "+emails +" Sha1password array "+sha1passwords)
    mailOptions.to=obj.to
    mailOptions.text="youer Sha 1 PassWord Is "+sha1pass;
    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
          resp.send("email_dont_send")
        } 
        else {
         resp.send("email_send");
        }
    });
}
    else {
        resp.send("email_dont_send")
    }

})
// function help check sha1
  var checkSha1 = (sha1passcheck,emailcheck) =>{
    console.log("Check sha1 function Emails Array "+emails +" Sha1password array "+sha1passwords)
    var iindex=-1;
    var jindex=-1;
    var status =false;
    for (var i=0; i<emails.length;i++)
    {
      console.log(emails[i] + " == ? " +emailcheck)
      if(emails[i]==emailcheck)
      iindex=i;
      console.log("I Index"+i)
    }
    for (var j=0; j<sha1passwords.length;j++)
    {
      console.log(sha1passwords[j] + " == ? " +sha1passcheck)
      if(sha1passwords[j]==sha1passcheck)
    {
      console.log("Sha 1 is equal")
      console.log("j Index"+j)
      jindex=j;
    }
    }
    if ((jindex == iindex) && (jindex != -1))
    {
      console.log(jindex +"==  "+ iindex )
      status=true;
      console.log("return from sha 1 true")
      return status;
    }
    else
    {
      status=false;
    return status;
    }
  }




// {sha1pass : ,  userName , newpassword:, email}

appRouter.route('/changewithoutpassword').post(async(req,resp)=>{
  //check login to change password
  email=req.body.email;
  sha1pass=req.body.sha1pass;
  console.log("Before CheckSha1")
  var getstatuslogin = checkSha1(sha1pass,email)
  console.log("get status Login "+getstatuslogin)
 // if (getstatuslogin ==false) {
    //resp.json({"message":"Dont_Change"});
  //}
  //else
  if (getstatuslogin==true){
  var arr=[];
  var obj = req.body;
  var perbyUser = await UserJson.getPerByUserName(req.body.userName);
  var status = await PasswordConfig.checkPassword(obj.userName,obj.newpassword) // all information
  var newpass = await PasswordConfig.hashsalastedPasswordToDb(obj.newpassword);
  arr.push(newpass);
  for (var i=0;i<ConfigPass.requirments.HistoryOfPassword-1;i++)
  {
      arr.push( perbyUser.HistoryPassword[i]);
  }

  var newOBJ = {
      Id:req.body.userName,
      HistoryPassword:arr,
      tryLogin:0
  }
  if (status == true)
  {
      var answer = await LoginDatabaseCOntroler.EditByIdUser(newOBJ);
      var answerDB = await userBL.getIdNumber(obj.userName);
      console.log("ID : "+answerDB._id)
      var IDMongo = answerDB._id;
      varNEWDB = {
          userName:obj.userName,
          password:newpass
      }
      var answer2 = await userBL.updateUser(IDMongo,varNEWDB)
      //remove from arrays
      sha1passwords = sha1passwords.filter(function(item) {
        return item !== sha1pass
    })
    emails = emails.filter(function(item) {
      return item !== email
  })
  console.log("emails "+emails +" sha1 "+sha1passwords)
  console.log("get status Login "+getstatuslogin)
      resp.json({"message":"Change_True"});
  }
  else {
   resp.json({"message":"Dont_Change"});
  }
}
  else {
      resp.json({"message":"Dont_Change"});
  }
})


module.exports = appRouter