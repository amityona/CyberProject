var express = require ('express')
var appRouter = express.Router()
var userBL = require('../models/userBL')
var axios =require('axios')
const UserJson = require('../LoginDataBase/LoginDataBaseController');
const PasswordConfig = require('../PasswordConfig/passwordConfig')
const LoginDatabaseCOntroler = require('../LoginDataBase/LoginDataBaseController')
const ConfigPass =require('../PasswordConfig/ConfigPassword');
 //Permission
appRouter.route('/').get(async(req,resp)=>{
    var  users = await UserJson.readPermissions();
    return resp.json(users)
})

//for me!
appRouter.route('/getperbyusername/:id').get(async(req,resp)=>{
    UserJson.getPerByUserName(req.params.id)
    .then(x=>{return resp.send(x)})
    .catch(err=>{return resp.send(err)})
})
//{userName , password ,newpassword}
appRouter.route('/ChangePassword').post(async(req,resp)=>{
    //check login to change password
    var getstatuslogin = await loginfunc(req.body.userName,req.body.password)
    if (getstatuslogin==true){
    var arr=[];
    var obj = req.body;
    var perbyUser = await UserJson.getPerByUserName(req.body.userName);
    var status = await PasswordConfig.checkPassword(obj.userName,obj.newpassword) // all information
    var newpass = await PasswordConfig.hashsalastedPasswordToDb(obj.newpassword);
    arr.push(newpass);
    for (var i=0;i<ConfigPass.requirments.HistoryOfPassword-1;i++)
    {
        arr.push( perbyUser.HistoryPassword[i]);
    }

    var newOBJ = {
        Id:req.body.userName,
        HistoryPassword:arr,
        tryLogin:0
    }
    if (status == true)
    {
        var answer = await LoginDatabaseCOntroler.EditByIdUser(newOBJ);
        var answerDB = await userBL.getIdNumber(obj.userName);
        console.log("ID : "+answerDB._id)
        var IDMongo = answerDB._id;
        varNEWDB = {
            userName:obj.userName,
            password:newpass
        }
        var answer2 = await userBL.updateUser(IDMongo,varNEWDB)
        resp.json({"message":"Change_True"});
    }
    else {
     resp.json({"message":"Dont_Change"});
    }
}
    else {
        resp.json({"message":"Dont_Change"});
    }
})
/*
appRouter.route('/getperbyusername/:id').get(async(req,resp)=>{
    UserJson.getPerByUserName(req.params.id)
    .then(x=>{return resp.send(x)})
    .catch(err=>{return resp.send(err)})
})

*/

var loginfunc = async (userName,password)=>{
    var Users = await userBL.getAllUsers()
  //userBL.getAllUsers().then((Users)=>{
    //decrypt pass
    var hashedPassword = await PasswordConfig.hashsalastedPasswordToDb(password)
    console.log("Users Length "+Users.length)
for (let i=0;i<Users.length;i++)
{
    if ((Users[i].userName == userName) && (Users[i].password==hashedPassword))
    {
     console.log("TRUE CONNECT")
    return true;
    }
}

        return false

}
//.catch((err)=>console.log(err))

module.exports = appRouter