var express = require ('express')
var crypto = require('crypto')
var app = express();
var appRouter = express.Router()
var UserBL = require('../models/userBL')
var checkP = require('../PasswordConfig/passwordConfig')
var ReqConfig= require('../PasswordConfig/ConfigPassword')
var LoginDataBase = require('../LoginDataBase/LoginDataBaseController')
var jwtBL = require('../models/jwtBL')
//users
appRouter.route('/').get(async(req,resp)=>{
    var  users = await UserBL.getAllUsers()
    return resp.json(users)
})
//users/login
appRouter.route('/login').post(async(req,resp)=>{
    var Users = await UserBL.getAllUsers()
    let obj = req.body;
    //decrypt pass
    passD=obj.password;
    var hashedPassword = await checkP.hashsalastedPasswordToDb(passD)
    var status="Not Login"
    var JsonData = await LoginDataBase.getPerByUserName(obj.userName)

    ObjIfFailLogin = {
            "Id":JsonData.Id,
            "HistoryPassword":JsonData.HistoryPassword,//before hash password
            "tryLogin":JsonData.tryLogin+1
    
        }
    if(JsonData.tryLogin < ReqConfig.requirments.tryLogin)
    {
for (let i=0;i<Users.length;i++)
{
    if ((Users[i].userName == obj.userName) && (Users[i].password==hashedPassword))
    {
    status="Login"
    var token = await jwtBL.makeToken();
    console.log("Token in server is  &!&#&!#!# "+token );
    }
}
    if (status == "Login")
    {
     ObjIfFailLogin.tryLogin=0;
     var AnswerJsonData = await LoginDataBase.EditByIdUser(ObjIfFailLogin) // rest trylogin
     return resp.json({"message":"Login","Token":token})

    }
    else { // password incorrect up try login and message 
        var AnswerJsonData = await LoginDataBase.EditByIdUser(ObjIfFailLogin)
        if (ObjIfFailLogin.tryLogin ==  ReqConfig.requirments.tryLogin-1) { // rset try login password
            var newRestObj=ObjIfFailLogin;
            newRestObj.tryLogin=0;
            setTimeout(RsetTryLoginTimer, 5 * 60 * 1000,newRestObj)//5 min
        }
        console.log("updated Json Login Data :"+AnswerJsonData);
        return resp.json({"message":"Dont_Login"})
    }

}
else {
    return resp.json({"message":"You Try more than try login config"})
}
})


appRouter.route('/:id').get(async(req,resp)=>{
    var id = req.params.id
    var user = await UserBL.getUserById(id)
    return resp.json(user)
})
// create new user 
appRouter.route('/').post(async(req,resp)=>{
    var length2 =ReqConfig.requirments.HistoryOfPassword;
    var newHistoryArr =[];
    for (var i=0;i<length2;i++) {
    newHistoryArr[i]="";
    //newHistoryArr.push("");
    }
    var  UserObj = req.body
    var checkUserVaild = await checkP.checkUserNameVaild(UserObj.userName);
    var status = await checkP.PassWordForCreateCheck(UserObj.userName,UserObj.password)
    if ((status ==true ) && (checkUserVaild==true))
    {
    var hashedPassword = await checkP.hashsalastedPasswordToDb(UserObj.password)
    UserObj.password=hashedPassword;
    UserObj.userName= req.body.userName;
    var user = await UserBL.addUser(UserObj)
    newHistoryArr[0]=hashedPassword;
    var objToJson = {
        "Id":UserObj.userName,
        "HistoryPassword":newHistoryArr,//before hash password
        "tryLogin":0

    }
    LoginDataBase.WriteJsonPermi(objToJson)
.then(x=>{console.log(x)})
.catch(err=>{return resp.send(err)})
    return resp.json(user)
    }
    else
    return resp.json("Invalid");
})

appRouter.route('/:id').put(async(req,resp)=>{
    var  UserObj = req.body
    var status = checkP.checkPassword(UserObj.userName,UserObj.password)
    if(status ==true )
    {
    var hashedPassword = await checkP.hashsalastedPasswordToDb(UserObj.password)
    UserObj.password=hashedPassword;
    UserObj.userName= req.body.userName;
   var result = await  UserBL.updateUser(id, UserObj)
   return resp.json(result)
    }
   else
    return resp.json("Invalid Password !");
})

appRouter.route('/:id').delete(async(req,resp)=>{
    var id =req.params.id
    var result = await  UserBL.deleteUser(id);
    return resp.json(result)
})


async function RsetTryLoginTimer(NewRestObj) {
    console.log("Interval Join to Reset")
    var AnswerJsonData = await LoginDataBase.EditByIdUser(NewRestObj)
}
module.exports = appRouter