const jfile = require('jsonfile')
// obj {"Id":"UserName","HistoryPassword":["","",""],"tryLogin":3}
var WriteJsonPermi = (obj) =>{
    return new Promise ((resolove,reject)=>{
        var arr=[];

        readPermissions().then(data=>{
            arr=data;
            arr.push(obj)
            jfile.writeFile('./LoginDataBase/LoginJson.json',arr,(err)=>{
            if(err) {
                reject(err)
            }
            else {
                resolove("Login Created in Json file")
            }
        })
        })
        .catch((err)=>console.log(err))
})
}

var readUsersByIdPermi = (id) => {
    return new Promise((resolve,reject)=>{
        jfile.readFile('./LoginDataBase/LoginJson.json',(err,data)=>{
            if(err){
                reject(err)
            }
            else{
                for (let i=0;i<data.length;i++)
                {
                    if(data[i].Id ==id){
               //resolve(returnValue)
               // console.log("Data i from read Users by ip permi"+data[i].Id +" histyory"+data[i].HistoryPassword)
               var obj= {
                   Id:data[i].Id,
                   HistoryPassword:data[i].HistoryPassword,
                   tryLogin:data[i].tryLogin
                   
               }
                resolve(obj)
                    }
                }
            }
        })
    })
}



var  readPermissions= () => {
    return new Promise((resolve,reject)=>{
        jfile.readFile('./LoginDataBase/LoginJson.json',(err,data)=>{
            if(err){
                reject(err)
            }
            else{
                resolve(data)
            }
        })
    })
}


var  deletePerById= (id) => {
    var arr=[];
    return new Promise((resolve,reject)=>{
        jfile.readFile('./LoginDataBase/LoginJson.json',(err,data)=>{
            if(err){
                reject(err)
            }
            else{
                for (let i=0;i<data.length;i++)
                {
                    if (data[i].UserName!=id)
                    arr.push(data[i]);
                    
                }
                resolve("Not Found")
            }
        })
    })
}



var  getPerByUserName= (username) => {
    return new Promise((resolve,reject)=>{
        jfile.readFile('./LoginDataBase/LoginJson.json',(err,data)=>{
            if(err){
                reject(err)
            }
            else{
                for (let i=0;i<data.length;i++)
                {
                    if (data[i].Id==username)
                    resolve(data[i]);
                }
                resolve("Not Found")
            }
        })
    })
}
// obj = { userName : a,HistoryPassword,  try:0}
var EditByIdUser = (obj) =>{
    return new Promise ((resolove,reject)=>{
        var arr=[];

        readPermissions().then(data=>{
            for (let i=0;i<data.length;i++)
            {
                if(data[i].Id != obj.Id)
                arr.push(data[i])
                else
                arr.push(obj);
            }
            jfile.writeFile('./LoginDataBase/LoginJson.json',arr,(err)=>{
            if(err) {
                reject(err)
            }
            else {
                resolove("Edit Complete "+arr)
            }
        })
        })
        .catch((err)=>console.log(err))
})
}

module.exports = {WriteJsonPermi, readPermissions,getPerByUserName,deletePerById,readUsersByIdPermi,EditByIdUser }//,readUsersByName}