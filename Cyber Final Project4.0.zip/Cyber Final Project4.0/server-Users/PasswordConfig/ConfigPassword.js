var crypto = require('crypto')
var fs = require('fs')
var requirments = {
    "lengthreq":1,
    "MustCapitaleLetter":false,
    "MustLitlleleLetter":false,
    "numbers":false,
    "specialChar":false,
    "HistoryOfPassword":3,
    "Dictionary":false,
    "tryLogin":3
}
var PrivateKeyPass = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDIITBaWkD4mwlP"+
"iTx2hyLD8CcUxQdrW7V8QqguOPaNPCI3UdQl/hNiDRtLmHTjMgvMVTLrshH5OqPb"+
"+0tzBbBfg9bBWKSeG8vhRg+fpWM+suFgml0/5Um8s7eUqifTAHeTmu5Z/FgNtH0F"+
"NNRRL64za/XzZMwAAxYzWAsasrGd5Z9z1aeU6ueXxMTTQ4sX6pM5rE4qBMzJrtXh"+
"+zVXP/ZCbSuWqtWgwFi94qdausN+p2eSYkud5LtY7pMeIbXdv3fULkxVzvAzK5x6"+
"qpvBMO+gCmO07TBnS4LMckaJXO+k8aV/kQhjp9rrED5V1kffHfV1L4bdYFrCu4ty"+
"jHeQWwFnAgMBAAECggEAPLrxkOGFiMuHSkcDfZZpgtsMCP33T+lfC+uwXIJ1sws1"+
"+OKQhczxtdXzW//SLKWhtep+zs5VLPPSCK3byfZGfN2lnDuZjM8zkdNwZ0pJcRvY"+
"T7fYJ00dkLFaurbd6eZg4v5naRAt6k7Eh4FuEortCnavBqKmUzSclo0XpYznYFnl"+
"92FWzTts+0Sxa3pyDYZktxfDMtKXliHUwUu97ncxUuQO7d/66eiCo8YB8o6kIdBo"+
"z01SsyecA6u+a10WPx37xELPzLnpZHdluuVrNxKZbV3Lk0mVaH5y07N9AcHCF5BS"+
"sNVCKZHICjfKG6mArfFcKt5WTqLfTgVyibQD9gDz3QKBgQDW4g94Nyf9skszGIwZ"+
"n5mp4G2yDY3iEVq/CFmvSN/vBApKXLO+IpbZ0Onhwank3wE/aoStLilfdU0CJP+K"+
"lYib7a75UqYy2+jQN/nxGdzoA8V9HAZTlKpU1t0FpCbSgsAdkvJp0JL3BLwoO/DI"+
"GL7WeOnDNezdlIG9mP9iXo0f1QKBgQDubHC0FhdhMF1CqjJSpbsI9Pz076bkvOfa"+
"YwSoVtHFh2tbzGCLlYUiRDTHujsC7krghJ9f1O/r1nPwWzicVnr7M/MatuGHJkwI"+
"BFJFlgYPwlR6JWvgiRQZqf4AAkLQew2EYeNM2zTYNipS9MIW06y4jodcG9qfm/QR"+
"K6nbYLz2SwKBgBzowu4IdZ/jCczxA4A7AaBiKj/nJOyCKzRCOlajtkTgxUWl3SS6"+
"YJMjUSPnOyUof3F5sineaQCHtnmQYrTRU1SvEHhIj0WOYm8I6N5v/VFVmI8xYwSB"+
"nrzVP10P7Y0qvA/+ghCMWAlVoL7E+arh8WLHV6PEsH5LCX1phQpF8DSVAoGBAI+6"+
"56ZouudoFJCfsX6JUltv9R5jaqTyDINmteQVkpgVru7EIl+DX6LsozTUW8bEiHcY"+
"/Er1Pz1ZJsN6+oGk0Lam9qLgJM0olSUwFbjFXBob+Hk6HfJaMLfX9rtioYy04c0w"+
"hapLa2v8Gz+vNWI1cSZBJfCtCfq2NUg0nk0V4FRJAoGAJBhbCxJoJy57j2QWhIVl"+
"dqAlBtTxvff7tlwpmCjMEjGjkCYwpoOvLqDvVqyf6UzIUQQWJbsjeaZdPSHZ1D3p"+
"Xdt6jHJATDonSgfjWPF6J2ZN+Vhg6KGnZSgO68fJZljRcxoQTCQ89q7sSCi6iaoZ"+
"kuLhn+mD232HiUW8ke+1jD0="
/*
const { generateKeyPair } = crypto
generateKeyPair('rsa', {
    modulusLength: 4096,
    publicKeyEncoding: {
        type: 'spki',
        format: 'pem'
    },
    privateKeyEncoding: {
        type: 'pkcs8',
        format: 'pem',
        cipher: 'aes-256-cbc',
        passphrase: 'top secret'
    }
}, (err, publicKey, privateKey) => {
    // Handle errors and use the generated key pair.
    if (err) throw err;
    fs.writeFileSync("keyPrivateMakeConfig.pem", privateKey)
    fs.writeFileSync("publicMakeConfig.pem", publicKey)
    //res.json({ publicKey, privateKey })

});
*/
module.exports = {requirments,PrivateKeyPass}