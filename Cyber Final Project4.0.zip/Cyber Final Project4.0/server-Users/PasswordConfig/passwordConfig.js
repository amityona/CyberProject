var config = require('./ConfigPassword')
var LoginDataBase = require('../LoginDataBase/LoginDataBaseController')
var bcrypt = require('bcrypt')
var userBL = require('../models/userBL')
configReq = config.requirments;
var LengthOfHistory = configReq.HistoryOfPassword;
checkPassword = async (username,password)=> {
/*
    var status = true;
    //check differnt bettween lastes password
    var newPASS =  await hashsalastedPasswordToDb(password)
    LoginDataBase.readUsersByIdPermi(username).then(data=>{
        var userjson1=data;
        console.log("Data i from read Users by ip permi"+data[i].Id +" histyory"+data[i].HistoryPassword)
        for (var i=0;i<userjson1.HistoryOfPassword;i++)
        {
            if (newPASS == userjson1.HistoryPassword[i])
            {
            status=flase;
            return false
            }
        }


    })
    .catch((err)=>console.log(err))
 */
var status =true;
var newPASS = await hashsalastedPasswordToDb(password);
var data = await LoginDataBase.readUsersByIdPermi(username);
var userjson1=data;
for (var i=0;i<LengthOfHistory;i++)
{
    if (newPASS == userjson1.HistoryPassword[i])
    {
    status=false;
    return false
    }
}
if(configReq.lengthreq != password.length ) {
    status=false;
    return false;
}

if (configReq.MustCapitaleLetter == true)
{
      var check=false;
         for (var i=0;i<password.length;i++){
             if ((password[i]>='A') && (password[i]<='Z'))
              check=true;
            }
         if (check==false){
             status=false;
             return flase;
            }
}

if (configReq.MustLitlleleLetter == true)
{
      var check=false;
         for (var i=0;i<password.length;i++){
             if ((password[i]>='a') && (password[i]<='z'))
              check=true;
            }
         if (check==false){
             status=false;
             return false;
            }
}
if (configReq.specialChar == true)
{
      var check=false;
         for (var i=0;i<password.length;i++){
             if ((password[i]>='!') && (password[i]<='/'))
              check=true;
            }
         if (check==false){
             status=false;
             return false;
            }
}
if (configReq.numbers== true)
{
      var check=false;
         for (var i=0;i<password.length;i++){
             if ((password[i]>='0') && (password[i]<='9'))
              check=true;
            }
         if (check==false){
             status=false;
             return false;
            }
}

console.log("------------!#*(!*# IN end A FUNCTIO N SATAUS !#!# "+status) 
//check try login < req.try..
return status

}
hashsalastedPasswordToDb = async (password)=> {
    try {
var salt = await bcrypt.genSalt(10);
salt="$2b$10$NJgd9MhMtVMBVSM8G0pGRO"; // need to be const
var hashedPassword = await bcrypt.hash(password,salt)
    }
    catch (error) {
    console.log(errorr);   
    }
    return hashedPassword;
}

checkUserNameVaild = async (userName)=>{
   var users = await userBL.getAllUsers();
   var StatusUserName=true;
   for (var i=0;i<users.length;i++)
   {
       if(userName == users[i].userName)
       StatusUserName=false;
   }
   return StatusUserName;
}




PassWordForCreateCheck = async (username,password)=> {

    var status =true;

    if(configReq.lengthreq != password.length ) {
        status=false;
        return false;
    }
    
    if (configReq.MustCapitaleLetter == true)
    {
          var check=false;
             for (var i=0;i<password.length;i++){
                 if ((password[i]>='A') && (password[i]<='Z'))
                  check=true;
                }
             if (check==false){
                 status=false;
                 return flase;
                }
    }
    
    if (configReq.MustLitlleleLetter == true)
    {
          var check=false;
             for (var i=0;i<password.length;i++){
                 if ((password[i]>='a') && (password[i]<='z'))
                  check=true;
                }
             if (check==false){
                 status=false;
                 return false;
                }
    }
    if (configReq.specialChar == true)
    {
          var check=false;
             for (var i=0;i<password.length;i++){
                 if ((password[i]>='!') && (password[i]<='/'))
                  check=true;
                }
             if (check==false){
                 status=false;
                 return false;
                }
    }
    if (configReq.numbers== true)
    {
          var check=false;
             for (var i=0;i<password.length;i++){
                 if ((password[i]>='0') && (password[i]<='9'))
                  check=true;
                }
             if (check==false){
                 status=false;
                 return false;
                }
    }
    
    console.log("------------!#*(!*# IN end A FUNCTIO N SATAUS !#!# "+status) 
    //check try login < req.try..
    return status
    
    }

module.exports = {checkPassword,hashsalastedPasswordToDb,checkUserNameVaild,PassWordForCreateCheck}