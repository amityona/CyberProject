var express = require ('express')
var app = express();
var appRouter = express.Router()
var prodcutsBL = require('../models/productsBL')
var jwtBL = require('../models/jwtBL')


var Bool_statusCheckToken;

appRouter.route('/').get(async(req,resp)=>{
    var products = await prodcutsBL.getAllproducts()
    return resp.json(products)
})
appRouter.route('/:id').get(async(req,resp)=>{
    var id = req.params.id
    var products = await prodcutsBL.getproductsById(id)
    return resp.json(products)
})

appRouter.route('/').post(async(req,resp)=>{
    try {
     var Token = req.headers.authorization.split(' ')[1];

    Bool_statusCheckToken = jwtBL.checkToken2(Token);
    var products = req.body
    var product = await prodcutsBL.addproducts(products)

    return resp.json(product)
    }
catch(err) {
    resp.json({"message":"errorr"
    ,"Err":err
});
}
})
appRouter.route('/:id').put(async(req,resp)=>{
   var id = req.params.id
   var products = req.body
   var result = await prodcutsBL.updateproducts(id,products)
   return resp.json(result)
})

appRouter.route('/:id').delete(async(req,resp)=>{
    var id =req.params.id
    var result = await prodcutsBL.deleteproducts2(id);
    return resp.json(result)
})

module.exports = appRouter