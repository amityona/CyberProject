var Products = require ('./productsSchema')

var getAllproducts = () => {
    return new Promise((resolve,reject)=>{
        Products.find({},(err,data)=>{
            if(err){
                reject(err);
            }
            else{
                resolve(data);
            }
        })
    })
}

var getproductsById = (carId) => {
    return new Promise ((resolve,reject)=>{
        Products.findById(carId,(err,data)=>{
            if(err){
                reject(err)
            }
            else{
                resolve(data)
            }
        })
    })
}

var addproducts = (newProcuts) => {
    return new Promise((resolve,reject)=>{
        
        var ProcuesToDB = new Products ({
            title: newProcuts.title,
            price: newProcuts.price,
            nameOfImg: newProcuts.nameOfImg
        })
        console.log(ProcuesToDB);

        ProcuesToDB.save((err)=>{
            if(err){
                reject(err)
            }
            else{
                resolve(ProcuesToDB)
            }
        })
    })
}

var updateproducts = (carId,newCar) => {
    return new Promise((resolve,reject)=>{
        
        var updateCar = {
            model: newCar.model,
            color: newCar.color
        }

        Products.findByIdAndUpdate(carId,updateCar,(err)=>{
            if(err){
                reject(err)
            }
            else{
                resolve("Car was updated")
            }
        })
    })
}

var deleteproducts2 = (id) => {
    return new Promise((resolve,reject)=>{
        Products.findByIdAndDelete(id,(err)=>{
            if(err){
                reject(err)
            }
            else{
                resolve("Product deleted!!!")
            }
        })
    })
}


module.exports = {getAllproducts, getproductsById, addproducts, updateproducts, deleteproducts2}