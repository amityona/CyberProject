var jwt = require('jsonwebtoken')

var makeToken = async () => {
    var token2 = jwt.sign({
        id:"121212",
        password:"myPassword"
    },"SecretKey",{expiresIn:"1H"}
    )
    return token2;
}

var checkToken = async (req,res,next) => {
    try {
     const Token = req.headers.authorization.split(' ')[1]; // split Bearer token...
    jwt.verify(Token,"SecretKey",(err,infoJson)=>{
        if (err) { // only if or try needed
            res.status(401).json({message:"Auth File"})
        }
        //res.status(401).json({message:"Auth Success",infoOfCrpy:infoJson})
        return true;
    });
}
catch(err) {
    console.log(err);
    res.status(401).json({message:"Auth File"})
}
}

var checkToken2 = async (token) => {
    jwt.verify(token,"SecretKey",(err,infoJson)=>{
        if (err) { // only if or try needed
            return false;
        }
        //res.status(401).json({message:"Auth Success",infoOfCrpy:infoJson})
        return true;
    });
}

/*
var betterCheckToken = (req,res,next)=> {
    const Token = req.headers.authorization.split(' ')[1]; 
    jwt.verify(Token,"SecretKey",(err,jsonCryp)=>{
        if (err) {
            res.status(401).json({message:"Auth File"})
        }
        else{
            res.status(401).json({message:"Auth Success",info:jsonCryp})
        }
        
    })
}
*/
module.exports = {makeToken, checkToken,checkToken2}