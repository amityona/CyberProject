var mongoose = require('mongoose')

var appSchema = mongoose.Schema //הפונקצייה שמפעילה את הסכמה

var ProductsSchema = new appSchema ({
    title: String,
    price: Number,
    nameOfImg:String,
}) //בנאי שמקבל תבנית מסודרת לדאטה

module.exports = mongoose.model('ProductsNew',ProductsSchema)
//cars - collection name
//carSchema - הסכמה שתתחבר לקולקשטיין