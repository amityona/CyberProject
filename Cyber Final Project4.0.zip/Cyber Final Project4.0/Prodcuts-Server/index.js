
//change password
var express = require('express')
var https = require('https')
const path = require('path')
const fs=require('fs')
var cors = require('cors')
var bodyParser = require('body-parser')
var appRouter = express.Router()
var productsController = require('./controller/productsController')
var multer = require('multer')
require('./configs/products')

var app = express();

app.use(cors())

app.use(bodyParser.urlencoded({extended:true})).use(bodyParser.json())

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
    cb(null, 'img')
  },
  filename: function (req, file, cb) {
    cb(null,file.originalname )
  }
})
var upload = multer({ storage: storage }).single('file')

app.use('/products',productsController)
      
app.post('/upload',function(req, res) {

    console.log("UPLOAD")
     
    upload(req, res, function (err) {
           if (err instanceof multer.MulterError) {
               return res.status(500).json(err)
           } else if (err) {
            return res.status(500).json(err)
           }
      return res.status(200).send(req.file)

    })

});

app.get('/getimg/:nameOfImg', function(req, res) {
    var nameOfImg = req.params.nameOfImg;
    console.log("Name Of IMG "+nameOfImg)
  res.sendFile(path.join(__dirname, 'img/'+nameOfImg));
});

app.use('/',(req,res,next)=>{

    res.send('hello ssl')})

const sslServer = https.createServer({
    key: fs.readFileSync(path.join(__dirname,'cert','key.pem')),
    cert:fs.readFileSync(path.join(__dirname,'cert','cert.pem'))
},app)

sslServer.listen(3002 , ()=> console.log("secure server in 3002"))