import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Route,Link} from 'react-router-dom'
import { Switch } from 'react-router-dom/cjs/react-router-dom.min';
import Register from './compo/register';
import login from './compo/login';
import ChangePass from './compo/changepass'
import Homepage from './compo/HomePage'
import AddProduct from './compo/AddProduct'
import ForgetPassword from './compo/ForgetPassword'
import PartB from './compo/partB'
import React , {useState,useEffect } from 'react'
function App() {

  return (
    <div>
      <div className="header">
      <h1>Data Speed </h1>
      </div>
      <Switch>
        <Route path ="/register" exact component ={ Register }/>
        <Route path ="/login" exact component ={ login}/>
        <Route path ="/ChangePassword" exact component ={ ChangePass}/>
        <Route path ="/AddProduct" exact component ={ AddProduct}/>
        <Route path ="/ForgetPassword" exact component ={ ForgetPassword}/>
        <Route path ="/partb" exact component ={ PartB}/>
        <Route path ="/" exact component ={ Homepage}/>
      </Switch>
      <div className="footer">
      <h2 color="red"> Contact us</h2>
      </div>
    </div>
    
  );
}

export default App;
