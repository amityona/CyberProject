import React ,{useEffect,useState} from 'react'
import cookie from 'react-cookies'
import axios from 'axios'
import {Link} from 'react-router-dom';

function Login(props) {
const [userName,setUserName]= useState("");
const [password,setPassword]= useState("");
const [information,setinformation]= useState("");
const [trys,setStrys]= useState("");
    var Login_Click = async ()=> {
        var obj= {userName:userName,password:password};
        let getall = await axios.post("https://localhost:3001/users/login",obj)
        if (getall.data.message == "Login"){
            sessionStorage.setItem("login", "true");
            sessionStorage.setItem("userName", userName);
            sessionStorage.setItem("Token", getall.data.Token);
            alert("Token "+getall.data.Token);
            props.history.push('/');
        }
        else if (getall.data.message == "You Try more than try login config")
        setinformation("You Over The Try the connect pls wait");
        else if (getall.data.message=="Dont_Login") {
            var tryNumber =  await axios.get("https://localhost:3001/Permission/getperbyusername/"+userName)
            setStrys("More Login Tries Login :"+tryNumber.data.tryLogin) // how mutch more login try
            setinformation("Inccorrect User or password");
        }
        else if (tryNumber.data =="Not Found"){
            setinformation("User Not Found ");
            setStrys("");
        }
    }
    var StatusLogin = sessionStorage.getItem("login");
    console.log(StatusLogin);
    if(StatusLogin != "true")
    return (
        <div>
        <div className="topnav">
        <a href="/"> HomePage </a>
        <a href="/register"> Register </a>
        </div>
        <h2>Login Page :</h2>
        User Name :<input type="text" onChange={(e)=>{setUserName(e.target.value)}}></input> <br/> 
        Password :<input type="password" onChange={(e)=>{setPassword(e.target.value)}}></input> <br/>  
        <input type="button" value="Login" onClick={()=>{Login_Click()}}/> <br/>
        {information}
        {trys} <br/>
        </div>
    )
    else {
    return (
    <div>
    <h1>You Log IN</h1>
    <Link to="/">Back To Home Page</Link>
    </div>)
    }
}

export default Login
