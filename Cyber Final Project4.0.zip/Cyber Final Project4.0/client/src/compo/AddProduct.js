import React,{useState} from 'react'
import axios from 'axios'

function AddProduct(props) {
    const [selectedFile,SetSelectedFile] = useState(null);
    var Token = sessionStorage.getItem("Token");
    const headers = {
        'Authorization': "Bearer "+Token
      }
    var obj={};
    const [title,setTitle]=useState("");
    const [price,setprice]=useState("");
    const [id,setId]=useState("");

    var addProduct = async () =>{
    const data = new FormData() 
    data.append('file', selectedFile);
    axios.post("https://localhost:3002/upload", data, {})
.then(res => { // then print response status
    console.log(res.statusText)
 })

        obj={
            title:title,
            price:price,
            nameOfImg:selectedFile.name
            
        }
        let getall = await axios.post("https://localhost:3002/products",obj,{
            headers: headers
          })    
        props.history.push('/');
    }
    var deleteproducts = async ()=>{
        let getall = await axios.delete("https://localhost:3002/products/"+id,{
            headers: headers
          })    
          props.history.push('/');
    }
    var onChangeHandler = (event)=>{

        SetSelectedFile(event.target.files[0]);

    
    }
    return (
        <div>
            <div className="topnav">
                <a href="/"> HomePage </a>
            </div>
        Title :<input type="text" onChange={(e)=>{setTitle(e.target.value)}}></input> <br/> 
        Price :<input type="number" onChange={(e)=>{setprice(e.target.value)}}></input> <br/>  
        <input type="file" name="file" onChange={(e)=>{onChangeHandler(e)}}/> <br/>
        <input type="button" value="Add" onClick={()=>{addProduct()}}/> <br/>
       
        <h3>Delete By Id : </h3>
         ID :<input type="text" onChange={(e)=>{setId(e.target.value)}}></input> <br/>  
         <input type="button" value="Delete" onClick={()=>{deleteproducts();}}/> <br/>
        </div>
    )
}

export default AddProduct
