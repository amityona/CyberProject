import React ,{useEffect,useState} from 'react'
import cookie from 'react-cookies'
import axios from 'axios'

function ChangePass(props) {
const [username,setUserName]=useState("");
const [pass,setPassword]=useState("");
const [newpass,setnewpass]=useState("");
const [err,seterr]=useState("");

var Login_Click = async ()=> {
    var obj= {userName:username,password:pass,newpassword:newpass};
    let getall = await axios.post("https://localhost:3001/Permission/ChangePassword",obj)
    if (getall.data.message == "Change_True"){
  
        props.history.push('/');
    }
    else 
    {
        seterr("Dont Change ! Try Again");
    }
}



    return (
        <div>
        <div className="topnav">
        <a href="/"> HomePage </a>
        </div>
               <div>
        <h2>Change Password :</h2>
        User Name :<input type="text" onChange={(e)=>{setUserName(e.target.value)}}></input> <br/> 
        Password :<input type="password" onChange={(e)=>{setPassword(e.target.value)}}></input> <br/>  
        New  Password:<input type="password" onChange={(e)=>{setnewpass(e.target.value)}}></input> <br/>  
        <input type="button" value="Change Password" onClick={()=>{Login_Click()}}/> <br/>
        {err}
        </div>
            
        </div>
    )
}

export default ChangePass