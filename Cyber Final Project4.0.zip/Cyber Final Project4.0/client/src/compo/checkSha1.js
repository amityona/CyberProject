import React ,{useEffect,useState} from 'react'
import axios from 'axios'

function CheckSha1(props) {
const [username,setUserName]=useState("");
const [email,setemail]=useState("");
const [newpass,setnewpass]=useState("");
const [sha1pass,setsha1pass]=useState("");
const [err,seterr]=useState("");

var checkSha1func = async ()=> {
    var obj= {sha1pass:sha1pass,userName:username,newpassword:newpass,email:email};
    let getall = await axios.post("https://localhost:3001/mail/changewithoutpassword",obj)
    if (getall.data.message == "Change_True"){
  
        props.history.push('/')
    }
    else 
    {
        seterr("Dont Change ! Try Again");
    }
}

    return (
        <div>
            <div className="topnav">
            <a href="/"> HomePage </a>
            </div>
               <div>
        <h2> We sent to youer email sha1 Code :</h2>
        User Name :<input type="text" onChange={(e)=>{setUserName(e.target.value)}}></input> <br/> 
        Sha1 Code from Email :<input type="password" onChange={(e)=>{setsha1pass(e.target.value)}}></input> <br/>  
        New  Password:<input type="password" onChange={(e)=>{setnewpass(e.target.value)}}></input> <br/>  
        Email:<input type="text" onChange={(e)=>{setemail(e.target.value)}}></input> <br/> 
        <input type="button" value="Change Password" onClick={()=>{checkSha1func()}}/> <br/>
        {err}
        </div>
        <h3 style={{color:'Red',}} > Pay attetion <br/> new Password must stand in requirments </h3>
            
        </div>
    )
}

export default CheckSha1