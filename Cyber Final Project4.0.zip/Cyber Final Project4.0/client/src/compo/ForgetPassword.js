import React,{useState,useEffect} from 'react'
import axios from 'axios'
import CheckSha1 from './checkSha1'

function ForgetPassword(props) {

    const [email,setEmail]= useState("")
    const [err,setErr]=useState("")
    const [statusPage,setStatus]=useState(false)

    var ForgetPassword = async ()=>{
        var obj={to:email}
        var getanswer = await axios.post("https://localhost:3001/mail",obj);
        if (getanswer.data == "email_dont_send")
        setErr("Email Not found in users list");
        else {
            setStatus(true) //setStatus for put sha1
        }

    }

    if(statusPage==false) {
    return (
        <div>
        <div className="topnav">
        <a href="/"> HomePage </a>
        </div>
            <h1>Sent to email Forget Password : </h1> <br/>
            <h3> Youer Email Must to be real email </h3>
            <input type="text" onChange={(e)=>{setEmail(e.target.value)}}></input>
            <input type="button" value="Create Code" onClick={()=>{ForgetPassword()}}/> <br/>
            {err} <br/>
        </div>
    )
    }
    if (statusPage==true) {
   return ( 
       <div>
           <h2>Sha Page!!!!</h2>
        <CheckSha1/>
        </div>
   
    )

}
}
export default ForgetPassword
