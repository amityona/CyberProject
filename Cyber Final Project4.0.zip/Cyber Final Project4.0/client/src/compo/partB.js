import React ,{useEffect,useState} from 'react'
import axios from 'axios';
function PartB(props) {

const [information,Setinfo]=useState("");
const [answerinjection,Setstringinject]=useState([]);
const [userName,SetUserName]=useState("");
const [answerLogin,SetanswerLogin]=useState({});

var obarr="";
var  obarrlogin="";
var information2 = <h2>afaf</h2>

function createMarkup() {
    return {__html: information};
  }

  var injection = async()=>{
    var obj = {userName : { $gt : '\'a\''}}
    console.log(obj)
  var answer= await axios.get("https://localhost:3001/userinjection",obj);
  await Setstringinject(answer.data);
  console.log(answer.data)
  }
  
  var injectionLogin = async()=>{
    var obj = {userName : userName , password:{ $gt : '\'a\''}}
    console.log(obj)
  var answer= await axios.post("https://localhost:3001/injectlogin",obj);
  await SetanswerLogin(answer.data);
  var answerfromlogin = answer.data
  console.log("Answer4 "+answerfromlogin.Auth)
  if(answerfromlogin.Auth !="Login")
  {
    alert("Not found user")
  }
  else
  {
      sessionStorage.setItem("login", "true");
      sessionStorage.setItem("userName", userName);
      sessionStorage.setItem("Token", answerfromlogin.Token);
      alert("Token "+answerfromlogin.Token);
      props.history.push('/');
  }

  }

  obarr = answerinjection.map((elemnt,index)=>{
    return (<li key={index}> {elemnt.userName  } Password: {elemnt.password} Email : {elemnt.email} </li>)
})
    return (
        <div className="outer">
            <div className="b">
            <input type="button" value="Home Page" onClick={()=>{props.history.push('/')}} />
            <h2> Part B </h2>
            <h3> Enter Information</h3>
            <input type="text" onChange={(e)=>{Setinfo(e.target.value); createMarkup()}}></input>
            <div style={{border:'1px solid',padding:'0.5rem',backgroundColor:'green'}}>
            <h2>Example Of Secure</h2>
            {information}
            </div>
            <div style={{border:'1px solid',padding:'0.5rem',backgroundColor:'red'}}>
            <h2>Example Of Dont Secure</h2>
            <div dangerouslySetInnerHTML={createMarkup()}></div>
            </div>
            Examples Inputs need to add the tags <br/>
           1) img src="nonexistent.png" onerror="alert('This is alert message');" / <br/>
           2) ul li amit li li Second li ul <br/>
           </div>
           <div className="b">
            <h2> Injection DB</h2> <br/>
            String to function DB<input type="text" readOnly value="{userName : { $gt : '\'a\''}}"></input>
            <br/>
            <input type="button" onClick={()=>{injection()}} value="Inject"/>
            <input type="button" onClick={()=>{Setstringinject([])}} value="clear"/>
            <ul>
            {obarr}
            </ul>
           </div>
           <div className="b">
               <h2>login injecion</h2><br/>
              User name to injection<input type="text" onChange={(e)=>{SetUserName(e.target.value)}}></input>
            <br/>
               <input type="button" onClick={()=>{injectionLogin()}} value="Inject"/>
               {obarrlogin}
           </div>
        </div>
    )
}

export default PartB
