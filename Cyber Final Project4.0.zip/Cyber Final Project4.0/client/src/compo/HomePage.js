import React ,{useEffect,useState} from 'react'
import cookie from 'react-cookies'
import Login from './login'
import {Link} from 'react-router-dom';
import axios from 'axios'
import '../App.css'

function HomePage(props) {
    var obj="";
    var display="";
    var StatusLogin = sessionStorage.getItem("login");
    const [products,setProducts]= useState([]);

    useEffect(async ()=>{
        let getall = await axios.get("https://localhost:3002/products")    
        setProducts(getall.data)
        console.log("products : "+products)

    },[])
    if(StatusLogin != "true") {

        display= <div> <a href="/login">  Login </a> 
         <a href="/ForgetPassword">  Forgot Password </a>
         <a href="/partb">  Part B</a>
        </div>
       
       }
       if(StatusLogin == "true") {
        display= <div> <a href="/AddProduct"> Add Product </a>
          <a href="/"> <input type="button" value="LogOut" onClick={()=>{sessionStorage.setItem("login", "false"); sessionStorage.setItem("Token", "noToken");}}/> </a>
          <a href="/ChangePassword">  Change Password </a>
          <a href="/partb">  Part B</a>
         </div>
       }

   obj = products.map((elemnt,index)=>{
       var imgobj = elemnt.nameOfImg;
       var id1=elemnt._id;
       return (<tr key={index}>  
           <td>{id1}</td>
           <td>{elemnt.title}</td>
           <td>{elemnt.price}</td>
           <td>
           <img src={"https://localhost:3002/getimg/"+elemnt.nameOfImg} alt={elemnt.nameOfImg} width="120px" height="60px"/>
           </td>
       </tr>)
   })
    return (
        <div>
            <div className="topnav">
            <a href="/">  Home Page </a> 
            {display}
            </div>
         <h1>Our Products :</h1>
         <div style={{overflowX:'auto'}}>
         <table border="1px solid">
         <tr>
             <td>ID</td>
             <td>Title</td>
             <td>Price</td>
             <td>Image</td>
        </tr>
        {obj}
         </table>
        </div>
        </div>
    )
}

export default HomePage
