import React ,{useEffect,useState} from 'react'
import cookie from 'react-cookies'
import axios from 'axios'

function Register(props) {
const [userName,setUserName]= useState("");
const [email,setEmail]= useState("");
const [password,setPassword]= useState("");
const [obj,setOBJ]= useState("");
const [req,setreq]= useState("");
useEffect(async ()=>{
    console.log("Use Effect");
    let getall = await axios.get("https://localhost:3001/PasswordReq")    
    console.log(getall.data.requirments)
    var Capitale="false"
    var litlle="false"
    var numbers="false"
    var specialc="false"
    if (getall.data.requirments.MustCapitaleLetter == true)
    Capitale="Must"
    if (getall.data.requirments.MustLitlleleLetter == true)
    litlle="Must"
    if (getall.data.requirments.numbers == true)
    numbers="Must"
    if (getall.data.requirments.specialChar == true)
    specialc="Must"
    console.log(getall)
    var reqs = 
    <div> <li>Captiale Latter: {Capitale } </li> <br/> 
    <li>Littlle Latter :  {litlle} </li> <br/>
    <li>numbers :  {numbers} </li> <br/>
    <li>Length :  {getall.data.requirments.lengthreq} </li> <br/>
    <li>Special Char:  {specialc} </li> <br/>
       
    </div> 
    setreq(reqs);
  },[])

var RegisterAxios = async ()=>{
    var userToAdd = {
        userName:userName,
        email:email,
        password:password
    }
  
    let getall = await axios.post("https://localhost:3001/users",userToAdd)
    if (getall.data != "Invalid") //Entry was successful
    {
    console.log("Create a User Secusess");
    props.history.push('/');
    }
    else
    {
        setOBJ("Errorr to Submit Maybe same user name or password not stand in the config")
    }
    

}

    return (
        <div>
        <h2>Register Page :</h2>
        Email :<input type="text" onChange={(e)=>{setEmail(e.target.value)}}></input><br/>
        User Name :<input type="text" onChange={(e)=>{setUserName(e.target.value)}}></input> <br/> 
        Password :<input type="password" onChange={(e)=>{setPassword(e.target.value)}}></input> <br/>  
        <input type="button" value="Register" onClick={RegisterAxios}/> <br/>
        {obj}
        <h3> Dynamic Requiments Password and user </h3>
        <ul>
            <li> Username  doesn't exist in the system </li>
            {req}
        </ul>
        </div>
    )
}

export default Register
