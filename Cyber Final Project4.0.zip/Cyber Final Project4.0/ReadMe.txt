Email: Amityona61967@gmail.com

run Npm Install eatch folder 

in two server side run in the folder node index
in the client side run in the folder npm start 
run on google chrome

client run on:https://localhost:3000
server run on:https://localhost:3001